"""
Shared utility functions used across multiple services.
"""


def helper_function():
    pass
