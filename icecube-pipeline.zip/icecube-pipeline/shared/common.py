"""
Common configuration settings and functions shared across services.
"""

DEBUG_MODE = True
