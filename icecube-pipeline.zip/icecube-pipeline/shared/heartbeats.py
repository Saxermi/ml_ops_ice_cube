"""
Heartbeat functions to check the health of different services.
"""


def send_heartbeat():
    print("Heartbeat sent")
